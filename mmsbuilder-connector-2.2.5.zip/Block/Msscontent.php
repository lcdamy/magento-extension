<?php
namespace Mmsbuilder\Connector\Block;

/**
 * Msscontent block
 */
class Msscontent extends \Magento\Framework\View\Element\Template
{
    public function getContent()
    {
        ?>
    <?php
    }
}

