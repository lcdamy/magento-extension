var config = {
    paths: {
        "jquery.cookie": "HelloBrave_CookieCompliance/js/jquery.cookie"
    }
};
